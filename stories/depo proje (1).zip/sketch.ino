#include "DHT.h"

#define DHTPIN 2      
#define DHTTYPE DHT22 

#define RELAY_PIN 7   
#define GREEN_LED 8   
#define RED_LED 9     
#define BUZZER_PIN 10 

const float ALT_ESIK = 20.0;  
const float UST_ESIK = 30.0;  

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600); 
  dht.begin();        
  
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {
  delay(2000); // 2 saniyede bir ölçüm yap

  float sicaklik = dht.readTemperature(); 
  float nem = dht.readHumidity();         

  if (isnan(sicaklik) || isnan(nem)) {
    Serial.println("Hata: Sensör verisi okunamıyor!");
    return; 
  }

  Serial.print("Sıcaklık: ");
  Serial.print(sicaklik);
  Serial.print(" °C | Nem: %");
  Serial.println(nem);

  // --- ARALIK KONTROLÜ VE KESİNTİSİZ SES MANTIĞI ---
  if (sicaklik > UST_ESIK) {
    // 🔴 DURUM 1: AŞIRI SICAK
    Serial.println("[UYARI] Yüksek Sıcaklık! Fan Aktif.");
    
    digitalWrite(RELAY_PIN, HIGH); 
    digitalWrite(RED_LED, HIGH);   
    digitalWrite(GREEN_LED, LOW);  
    
    // Sesi kapatmıyoruz, sıcaklık yüksek olduğu sürece sürekli 1000 Hz çalacak
    tone(BUZZER_PIN, 1000); 
  } 
  else if (sicaklik < ALT_ESIK) {
    // 🔵 DURUM 2: AŞIRI SOĞUK
    Serial.println("[UYARI] Düşük Sıcaklık! Don Tehlikesi.");
    
    digitalWrite(RELAY_PIN, LOW);  
    digitalWrite(RED_LED, HIGH);   
    digitalWrite(GREEN_LED, LOW);  
    
    // Don tehlikesinde sürekli daha kalın (500 Hz) bir alarm çalacak
    tone(BUZZER_PIN, 500); 
  } 
  else {
    // 🟢 DURUM 3: İDEAL ORTAM
    Serial.println("[STABİL] Sıcaklık İdeal Aralıkta.");
    
    digitalWrite(RELAY_PIN, LOW);  
    digitalWrite(RED_LED, LOW);    
    digitalWrite(GREEN_LED, HIGH); 
    
    // Sadece sıcaklık normale döndüğünde ses tamamen kesilecek
    noTone(BUZZER_PIN);            
  }
}